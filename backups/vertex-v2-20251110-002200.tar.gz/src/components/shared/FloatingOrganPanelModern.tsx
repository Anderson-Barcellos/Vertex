import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { CaretLeft, CaretRight } from '@phosphor-icons/react';
import OrganSection from '@/components/original/OrganSection';
import type { Organ, Finding } from '@/data/organs';
import type { SelectedFinding, FindingInstance } from '@/types/report';
import { useDropdownGuard } from '@/hooks/useDropdownGuard';
import { useOutsidePointerDismiss } from '@/hooks/useOutsidePointerDismiss';

type FindingDetailsComponentProps = {
  finding: Finding;
  organId: string;
  severity?: string;
  instances?: FindingInstance[];
  onSeverityChange: (severity: string) => void;
  onInstancesChange: (instances: FindingInstance[]) => void;
};

type FloatingOrganPanelModernProps = {
  organ: Organ;
  selectedFindings: SelectedFinding[];
  isNormal: boolean;
  isMinimized: boolean;
  onToggleMinimized: (minimized: boolean) => void;
  onFindingChange: (
    organId: string,
    categoryId: string,
    findingId: string,
    checked: boolean,
    finding: Finding,
    severity?: string,
    instances?: FindingInstance[]
  ) => void;
  onNormalChange: (organId: string, isNormal: boolean) => void;
  leftCss?: string; // ex.: 'calc(25% + 1.5rem)'
  widthExpanded?: string; // default '24rem'
  maxHeight?: string; // default 'calc(80vh)'
  FindingDetailsComponent?: React.ComponentType<FindingDetailsComponentProps>;
  followSidebar?: boolean; // Alinha ao lado direito da sidebar
  followGapPx?: number;    // Gap em px a partir da sidebar
  followNudgePx?: number;  // Correção fina (subtraída), para ajustar 1-6px à esquerda
};

export default function FloatingOrganPanelModern({
  organ,
  selectedFindings,
  isNormal,
  isMinimized,
  onToggleMinimized,
  onFindingChange,
  onNormalChange,
  leftCss = 'calc(25% + 1.5rem)',
  widthExpanded = '24rem',
  maxHeight = '80vh',
  FindingDetailsComponent,
  followSidebar = true,
  followGapPx = 24,
  followNudgePx = 0
}: FloatingOrganPanelModernProps) {
  const ref = useRef<HTMLDivElement>(null);
  const { isAnyDropdownOpen } = useDropdownGuard([ref]);
  const [leftPx, setLeftPx] = useState<number | null>(null);

  useOutsidePointerDismiss({
    containerRef: ref,
    isDisabled: isMinimized,
    isDropdownOpen: isAnyDropdownOpen,
    onDismiss: () => onToggleMinimized(true)
  });

  // Mantém o painel ancorado na borda direita da sidebar
  useEffect(() => {
    if (!followSidebar) return;

    const getSidebarContainer = () => document.querySelector('[data-sidebar] .glass-sidebar') as HTMLElement | null;

    const updateLeft = () => {
      const el = getSidebarContainer();
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const effectiveNudge = isMinimized ? (followNudgePx ?? 0) : 0;
      const nextLeft = Math.max(0, Math.round(rect.right + (followGapPx ?? 8) - effectiveNudge));
      setLeftPx(nextLeft);
    };

    updateLeft();
    const onResize = () => updateLeft();
    const onScroll = () => updateLeft();
    window.addEventListener('resize', onResize);
    window.addEventListener('scroll', onScroll, { passive: true });

    let ro: ResizeObserver | null = null;
    const sidebarContainer = getSidebarContainer();
    if (sidebarContainer && 'ResizeObserver' in window) {
      ro = new ResizeObserver(updateLeft);
      ro.observe(sidebarContainer);
      const grid = sidebarContainer.closest('.grid') as HTMLElement | null;
      if (grid) ro.observe(grid);
    }

    return () => {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('scroll', onScroll);
      ro?.disconnect();
    };
  }, [followSidebar, followGapPx, followNudgePx, isMinimized]);

  const panel = (
    <div
      ref={ref}
      className={`fixed top-24 organ-section-panel bg-white shadow-2xl border border-gray-200 rounded-2xl transition-all duration-300 ${
        isMinimized ? 'w-12' : 'overflow-y-auto modern-scrollbar'
      }`}
      style={{ left: followSidebar && leftPx !== null ? leftPx : (leftCss as any), width: isMinimized ? undefined : widthExpanded, maxHeight }}
    >
      {isMinimized ? (
        <div
          onClick={() => onToggleMinimized(false)}
          className="p-3 flex flex-col items-center cursor-pointer hover:bg-gray-100 transition-colors h-full rounded-2xl"
          title="Expandir painel"
        >
          <div className="mb-2 p-2">
            <CaretRight size={16} className="text-gray-700" />
          </div>
          <div className="writing-mode-vertical text-xs font-medium text-gray-900">
            {organ.name}
          </div>
        </div>
      ) : (
        <div className="h-full flex flex-col text-gray-900">
          <div className="absolute top-3 right-3 z-20">
            <button
              onClick={() => onToggleMinimized(true)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-700"
              title="Minimizar painel"
              aria-label="Minimizar painel"
            >
              <CaretLeft size={16} className="text-gray-700" />
            </button>
          </div>
          <div className="flex-1">
            <OrganSection
              organ={organ}
              selectedFindings={selectedFindings}
              onFindingChange={onFindingChange}
              onNormalChange={onNormalChange}
              isNormal={isNormal}
              FindingDetailsComponent={FindingDetailsComponent}
            />
          </div>
        </div>
      )}
    </div>
  );

  return createPortal(panel, document.body);
}
