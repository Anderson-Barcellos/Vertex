# Vertex V2 — Análise de Mercado, Valoração e Recomendações (Nov 2025)

Este documento resume o potencial de mercado para um software online de laudos ultrassonográficos com UI moderna e assistência por IA (Vertex V2), compara concorrentes, propõe precificação, estima cenários de receita e apresenta uma valoração em reais, além de recomendações práticas para acelerar o workflow do usuário.

## 1) Sumário Executivo

O Vertex V2 ataca um problema claro: geração de laudos de ultrassom de forma rápida, consistente e bonita, combinando formulários estruturados, modelos de frases determinísticas e geração/assistência por IA para impressão clínica. O mercado brasileiro já compra soluções similares (on‑premise e SaaS), e há espaço para um produto cloud-first com UX de alto nível, AI opcional com guardrails e integração simples com RIS/PACS. Oportunidade imediata em clínicas independentes, consultórios de gineco/obstetrícia e vascular, além de serviços de POCUS em hospitais.

## 2) Produto e Diferenciais

Produto: SPA React + Vite com layout A4, painel de achados por órgão, banco de frases normalizadas, geração de relatório por IA (Gemini/OpenAI) com fallback determinístico. Diferenciais propostos: experiência “fluida” moderna, streaming de IA no texto, arquitetura de painel flutuante, e opção de operar 100% sem IA quando necessário (com frases prontas + macros).

## 3) Concorrência Direta (BR) e Alternativas

Existem soluções online com foco em laudos e fluxo de imagem no Brasil, e uma base instalada relevante de ferramentas desktop.

Exemplos confirmados:

- SuperLaudo (SaaS por volume de laudos; tiers mensais/anuais por faixa de laudos). Fonte: site comercial, consulta em 05/nov/2025.
- Zanno (SaaS; preço público R$ 399/médico/mês). Fonte: site comercial, 05/nov/2025.
- WET Medical (telemedicina e edição de laudos; cobrança por laudo). Fonte: site comercial, 05/nov/2025.
- V‑Baby (obstétrico; planos por exame/mês). Fonte: site comercial, 05/nov/2025.
- Radiolaudos (plataforma de laudos com reconhecimento de voz e modelos). Fonte: site comercial, 05/nov/2025.
- LexusPACS (PACS web + módulo de laudos). Fonte: site comercial, 05/nov/2025.
- Turing/Queo Tecnologia (Windows; formulários orientados e banco de frases; não cloud‑native). Fonte: FAQ do fabricante, 05/nov/2025.

Observação: vários players anunciam ou já testam “IA para laudos”; poucos demonstram streaming/UX moderno consistente. Espaço para vencer por velocidade, simplicidade e interoperabilidade.

## 4) Mercado Endereçável (BR) e Dinâmica

- Estabelecimentos com diagnóstico por imagem no país: ~39,3 mil. Isso dá noção do universo de potenciais clientes institucionais. Fonte: Observatório Abramed (2025).
- Volume total de exames de imagem cresceu forte em 2024; o setor é a 2ª maior categoria em volume de exames. Fontes: SPR/Observatório Abramed (2024–2025).
- Sistema público realizou 101 milhões de exames de imagem em 2023; o privado cresceu acima de 40% em 2024. Fontes: CNN Brasil (dados oficiais), SPR/Abramed.

Observação metodológica: não há série pública consolidada e específica para “apenas ultrassom” acessível em aberto; a demanda, porém, é amplamente reconhecida como uma das maiores dentro de diagnóstico por imagem pela capilaridade e custo do método. Para dimensionamento, usamos número de estabelecimentos e referências de preços praticados.

## 5) Precificação sugerida (baseline)

- Assinatura por usuário médico: R$ 399/mês (referência direta do mercado)
- Excedente por laudo (uso): R$ 0,50–1,00 após franquia mensal (alinha com modelos por volume)
- Add‑ons opcionais: reconhecimento de voz médico, templates premium, exportação FHIR/HL7, SSO, on‑prem sync

Racional: combinar previsibilidade (assinatura) com captura de valor conforme volume. Permite tickets de R$ 400–2.000/mês por clínica pequena, com custo marginal baixo.

## 6) Cenários de Receita (12 meses pós‑MVP)

Cenário Conservador:

- 20 clínicas ativas; 60 assentos totais; 5.000 laudos/mês
- MRR cadeiras: 60 × 399 ≈ R$ 23.940
- MRR uso: ~R$ 3.000 (R$ 0,60 × 5.000)
- MRR total: ~R$ 27.000 | ARR: ~R$ 324.000

Cenário Base:

- 50 clínicas ativas; 150 assentos; 20.000 laudos/mês
- MRR cadeiras: 150 × 399 ≈ R$ 59.850
- MRR uso: ~R$ 12.000 (R$ 0,60 × 20.000)
- MRR total: ~R$ 71.850 | ARR: ~R$ 862.200

Cenário Agressivo:

- 150 clínicas ativas; 450 assentos; 60.000 laudos/mês
- MRR cadeiras: 450 × 399 ≈ R$ 179.550
- MRR uso: ~R$ 36.000 (R$ 0,60 × 60.000)
- MRR total: ~R$ 215.550 | ARR: ~R$ 2.586.600

Hipóteses: mix de clínicas independentes com 2–5 médicos cada; crescimento orgânico em especialidades que usam USG diariamente (gineco/obstetrícia, vascular, abdome geral, POCUS). Valores arredondados e sem impostos.

## 7) Valoração do Projeto (R$)

Referências de múltiplos: SaaS públicos de software caíram de picos de 2021; medianas atuais giram entre ~6–8× receita para empresas listadas, enquanto SaaS privados early‑stage e verticais em mercados emergentes tipicamente transacionam na faixa de 2–5× ARR, dependendo de crescimento, retenção e margem. Fontes: Reuters Breakingviews, Bessemer Cloud Index, SaaS Capital.

Aplicando a um produto “fully‑featured” com os cenários acima:

- Conservador: ARR ~ R$ 0,32 mi × 2–3× → R$ 0,6–0,9 mi
- Base: ARR ~ R$ 0,86 mi × 3–5× → R$ 2,6–4,3 mi
- Agressivo: ARR ~ R$ 2,59 mi × 4–6× → R$ 10,3–15,5 mi

Leitura de investidor: se o time entrega UX superior, integra com PACS/RIS simples e mantém churn < 2% ao mês, o alvo razoável de captação seed seria a faixa de R$ 2,5–4,0 milhões de valuation no cenário Base, subindo para R$ 8–12 milhões com sinais de PMF e 100+ clínicas pagantes.

## 8) Riscos e Compliance (BR)

- LGPD: dados de saúde são sensíveis; exigir criptografia em trânsito e repouso, controle de acesso, logs, consentimento quando aplicável e DPA com clientes. Anotações: Lei 13.709/2018 e Guia ANPD sobre dados de saúde.
- SaMD/ANVISA: software de apoio a laudo tende a não incidir como dispositivo médico quando não executa diagnóstico/medição autônoma; contudo, se oferecer cálculo diagnóstico automatizado ou auxílio clínico prescritivo, avaliar enquadramento e boas práticas da RDC 851/2024 (software para dispositivos médicos), com gestão de risco, ciclo de vida e rastreabilidade.
- Infra/Residência de dados: preferir data center no Brasil para clientes privados e órgãos públicos; avaliar BAA/HIPAA se atuar com parceiros fora do Brasil.

## 9) Recomendações de Produto e Workflow

- Frases prontas primeiro, IA opcional: manter geração de corpo do laudo por templates determinísticos e usar LLM apenas para a “Impressão/Conclusão”. Já há fallback implementado; expandir catálogo por órgão e especialidade.
- Auto‑inserção imediata: ao marcar um achado, inserir a frase correspondente no texto com placeholders preenchidos (tamanho, localização) e highlight de campos faltantes. Evita depender de IA para o miolo.
- Catálogo versionado + telemetria: versionar frases por especialidade, sugerir top‑frases por frequência do usuário, permitir “meus macros”.
- Guardrails de IA: prompt fixo e instruções clínicas conservadoras; proibir linguagem diagnóstica conclusiva quando não houver confirmação; logs e auditoria.
- Interoperabilidade: exportar PDF com assinatura ICP‑Brasil, FHIR DiagnosticReport e, quando aplicável, DICOM SR; integrar com Orthanc/Ohif via webhooks.
- Offline/On‑prem: opcional desktop (Tauri) com cache criptografado para ambientes sem internet; sync assíncrono quando online.
- Voz médica: integrar reconhecimento de voz especializado (ex.: modelagem acústica médica) com correção pós‑processada e dicionário customizável.
- Segurança por design: RBAC simples (admin/médico/recepção), 2FA, trilha de auditoria e backups automáticos.

## 10) Roadmap Sugerido (90 dias)

- Mês 1: consolidar templates por exame (abdome total, carótidas, gineco/obstetrícia), exportação PDF assinável e presets de impressão; telemetria de uso; página de “Frases & Macros”.
- Mês 2: integrações mínimas viáveis (export FHIR, webhook para PACS/Orthanc), onboarding guiado e importação de logo/cabeçalho por clínica.
- Mês 3: voz médica, cenários offline/light on‑prem, relatórios de uso/billing por volume; piloto com 5–10 clínicas.

## 11) Conclusão

Há mercado no Brasil para um laudo de ultrassom online bem executado; os concorrentes confirmam a disposição a pagar, e poucos combinam UX moderna com IA sob controle e interoperabilidade simples. Com execução focada em tempo‑de‑laudo e confiabilidade, o Vertex V2 pode disputar share rapidamente em nichos de alto volume. A valoração sugerida deve ancorar a captação no cenário Base e se ajustar conforme tração real nos próximos meses.

## 12) Fontes (acessadas em 05/nov/2025)

- SuperLaudo — planos por volume: https://www.superlaudo.com/precos
- Zanno — preço por médico: https://zanno.com.br
- WET Medical — edição de laudos por laudo: https://wet.com.br
- V‑Baby — planos por exame: https://vbaby.com.br
- Radiolaudos — plataforma de laudos: https://radiolaudos.com.br
- LexusPACS — portal web e laudos: https://lexuspacs.com.br
- Queo Tecnologia Turing (FAQ): https://queotecnologia.sistemahawk.app.br/faq
- Abramed — 39,3 mil estabelecimentos de saúde; Observatório 2025: https://abramed.org.br
- SPR — crescimento DI 2024: https://portal.spr.org.br
- CNN Brasil — 101 milhões de exames de imagem no SUS em 2023: https://www.cnnbrasil.com.br/saude/numero-de-exames
- Reuters Breakingviews — múltiplos SaaS 2024: https://www.reuters.com/breakingviews/
- Bessemer Cloud Index — medianas de valuation SaaS: https://www.bvp.com/atlas/cloud-index
- SaaS Capital — benchmarks SaaS privados: https://www.saas-capital.com/metrics
- HL7 FHIR DiagnosticReport: https://hl7.org/fhir/diagnosticreport.html
- OHIF DICOM Viewer: https://ohif.org
- ANPD — Guia LGPD em saúde: https://www.gov.br/anpd/pt-br/assuntos/noticias/guia-de-tratamento-de-dados-pessoais-pelo-poder-publico-no-segmento-de-saude
- ANVISA RDC 851/2024 — Software para dispositivos médicos: https://www.in.gov.br
