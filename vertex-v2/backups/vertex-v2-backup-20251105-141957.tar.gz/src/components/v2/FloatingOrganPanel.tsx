import React, { useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { CaretLeft, CaretRight } from '@phosphor-icons/react';
import OrganSection from '@/components/original/OrganSection';
import type { Organ, Finding } from '@/data/organs';
import type { SelectedFinding, FindingInstance } from '@/types/report';

type FindingDetailsComponentProps = {
  finding: Finding;
  organId: string;
  severity?: string;
  instances?: FindingInstance[];
  onSeverityChange: (severity: string) => void;
  onInstancesChange: (instances: FindingInstance[]) => void;
};

const SAFE_OUTSIDE_SELECTORS: string[] = [
  '[data-radix-portal]',
  '[data-radix-popper-content-wrapper]',
  '[data-radix-select-content]',
  '[data-radix-select-portal]',
  '[data-radix-select-trigger]',
  '[data-radix-select-viewport]',
  '[data-radix-select-item]',
  '[data-radix-dropdown-menu-content]',
  '[data-radix-combobox-portal]',
  '[data-radix-combobox-content]',
  '[data-radix-popover-content]',
  '[data-state="open"]',
  '[data-custom-dropdown="open"]',
  '.select-content',
  '.select-trigger'
];

const SAFE_OUTSIDE_ROLES: string[] = ['listbox', 'option', 'combobox', 'dialog', 'menu', 'menuitem', 'tooltip'];
const SAFE_DATA_SLOTS = new Set([
  'select',
  'select-trigger',
  'select-content',
  'select-item',
  'select-value',
  'select-viewport'
]);

const matchesSafeDropdownZone = (element: HTMLElement | null): boolean => {
  if (!element) {
    return false;
  }

  for (let index = 0; index < SAFE_OUTSIDE_SELECTORS.length; index += 1) {
    const selector = SAFE_OUTSIDE_SELECTORS[index];
    if (element.closest(selector)) {
      return true;
    }
  }

  const roleValue = element.getAttribute('role');
  if (roleValue && SAFE_OUTSIDE_ROLES.includes(roleValue)) {
    return true;
  }

  const dataState = element.getAttribute('data-state');
  if (dataState === 'open') {
    return true;
  }

  const ariaExpanded = element.getAttribute('aria-expanded');
  if (ariaExpanded === 'true') {
    return true;
  }

  const dataSlot = element.getAttribute('data-slot');
  if (dataSlot && SAFE_DATA_SLOTS.has(dataSlot)) {
    return true;
  }

  const dataCustomDropdown = element.getAttribute('data-custom-dropdown');
  if (dataCustomDropdown === 'open') {
    return true;
  }

  return false;
};

const eventPathHasSafeZone = (
  path: EventTarget[],
  panelElement: HTMLDivElement | null
): boolean => {
  for (let index = 0; index < path.length; index += 1) {
    const node = path[index];
    if (!(node instanceof HTMLElement)) {
      continue;
    }

    if (panelElement && panelElement.contains(node)) {
      return true;
    }

    if (matchesSafeDropdownZone(node)) {
      return true;
    }
  }

  return false;
};

interface FloatingOrganPanelProps {
  /** Current organ selected */
  organ: Organ | null;

  /** Selected findings for this organ */
  selectedFindings: SelectedFinding[];

  /** Is organ marked as normal */
  isNormal: boolean;

  /** Is panel minimized */
  isMinimized: boolean;

  /** Toggle minimized state */
  onToggleMinimized: (minimized: boolean) => void;

  /** Finding change handler */
  onFindingChange: (
    organId: string,
    categoryId: string,
    findingId: string,
    checked: boolean,
    finding: Finding,
    severity?: string,
    instances?: FindingInstance[]
  ) => void;

  /** Normal organ change handler */
  onNormalChange: (organId: string, isNormal: boolean) => void;

  /** Optional: custom finding details component */
  FindingDetailsComponent?: React.ComponentType<FindingDetailsComponentProps>;
}

/**
 * FloatingOrganPanel - Painel flutuante via React Portal
 *
 * Renderiza o OrganSection em um painel flutuante com posicionamento fixo
 * na viewport, permitindo minimização e detecção de cliques externos.
 *
 * Features:
 * - React Portal (renderiza fora da hierarquia DOM do grid)
 * - Posicionamento fixo (top-left da viewport)
 * - Minimização com ícones Phosphor
 * - Click-outside detection (ignora dropdowns Radix UI)
 * - Transições suaves
 * - Texto vertical quando minimizado
 */
export function FloatingOrganPanel({
  organ,
  selectedFindings,
  isNormal,
  isMinimized,
  onToggleMinimized,
  onFindingChange,
  onNormalChange,
  FindingDetailsComponent
}: FloatingOrganPanelProps) {
  const panelRef = useRef<HTMLDivElement>(null);

  // Click outside to minimize (excluding Radix UI portals)
  useEffect(() => {
    if (!organ) {
      return;
    }

    const handlePointerDown = (event: PointerEvent) => {
      if (isMinimized) {
        return;
      }

      const target = event.target as HTMLElement | null;

      if (panelRef.current && target && panelRef.current.contains(target)) {
        return;
      }

      const composedPath =
        typeof event.composedPath === 'function'
          ? event.composedPath()
          : [];

      if (eventPathHasSafeZone(composedPath, panelRef.current)) {
        return;
      }

      if (matchesSafeDropdownZone(target)) {
        return;
      }

      onToggleMinimized(true);
    };

    document.addEventListener('pointerdown', handlePointerDown, true);
    return () => {
      document.removeEventListener('pointerdown', handlePointerDown, true);
    };
  }, [organ, isMinimized, onToggleMinimized]);

  // Don't render if no organ selected
  if (!organ) return null;

  const panelContent = (
    <div
      ref={panelRef}
      className="fixed top-20 left-[272px] lg:left-[256px] md:left-[240px] z-[55] bg-card border border-border rounded-lg shadow-2xl backdrop-blur-sm transition-all duration-300"
      style={{
        width: isMinimized ? '48px' : '360px',
        maxHeight: 'calc(100vh - 120px)'
      }}
    >
      {isMinimized ? (
        // Minimized state: vertical bar with organ name
        <div
          onClick={() => onToggleMinimized(false)}
          className="p-3 flex flex-col items-center cursor-pointer hover:bg-muted/50 transition-colors h-full rounded-lg"
          title={`Expandir painel - ${organ.name}`}
        >
          <div className="mb-2 p-2 hover:bg-primary/10 rounded-md transition-colors">
            <CaretRight size={16} className="text-muted-foreground" />
          </div>
          <div className="writing-mode-vertical text-xs font-medium text-muted-foreground flex-1 flex items-center justify-center">
            {organ.name}
          </div>
        </div>
      ) : (
        // Expanded state: full organ section
        <div className="h-full flex flex-col">
          {/* Minimize button - positioned absolutely */}
          <div className="absolute top-2 right-2 z-20">
            <button
              onClick={() => onToggleMinimized(true)}
              className="p-1.5 hover:bg-muted rounded-md transition-colors"
              title="Minimizar painel"
              aria-label="Minimizar painel"
            >
              <CaretLeft size={16} className="text-muted-foreground" />
            </button>
          </div>

          {/* OrganSection component */}
          <div className="h-full overflow-hidden">
            <OrganSection
              organ={organ}
              selectedFindings={selectedFindings}
              onFindingChange={onFindingChange}
              onNormalChange={onNormalChange}
              isNormal={isNormal}
              FindingDetailsComponent={FindingDetailsComponent}
            />
          </div>
        </div>
      )}
    </div>
  );

  // Render via portal to document.body
  return createPortal(panelContent, document.body);
}

export default FloatingOrganPanel;
