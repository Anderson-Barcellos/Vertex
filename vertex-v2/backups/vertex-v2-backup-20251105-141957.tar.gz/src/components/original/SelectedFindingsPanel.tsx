import React, { useMemo, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { SelectedFinding, ReportData, type AIProvider } from '@/types/report';
import { organs as defaultOrgans, type Organ } from '@/data/organs';
import { FileText, Lightning, CaretDown } from '@phosphor-icons/react';
import { cn } from '@/lib/utils';

// Model configurations
const GEMINI_MODELS = [
  { id: 'gemini-2.0-flash-exp', name: 'Gemini 2.0 Flash', description: 'Rápido e eficiente' },
  { id: 'gemini-2.5-pro', name: 'Gemini 2.5 Pro', description: 'Mais avançado' },
  { id: 'gemini-flash-lite-latest', name: 'Gemini 2.5 Lite', description: 'Leve e econômico' }
];

const OPENAI_MODELS = [
  { id: 'gpt-4o', name: 'GPT-4o', description: 'Modelo otimizado' },
  { id: 'gpt-5-nano', name: 'GPT-5 Nano', description: 'Último modelo' }
];

interface SelectedFindingsPanelProps {
  selectedFindings: SelectedFinding[];
  normalOrgans: string[];
  organsList?: Organ[];
  onGenerateReport: (data: ReportData, options: { model: AIProvider; specificModel: string }) => Promise<void>;
  isGenerating?: boolean;
  className?: string;
  expandToContent?: boolean;
}

export default function SelectedFindingsPanel({
  selectedFindings,
  normalOrgans,
  organsList = defaultOrgans,
  onGenerateReport,
  isGenerating = false,
  className,
  expandToContent = false
}: SelectedFindingsPanelProps) {
  const [selectedModel, setSelectedModel] = useState<AIProvider>('gemini');
  const [selectedGeminiModel, setSelectedGeminiModel] = useState(GEMINI_MODELS[0].id);
  const [selectedOpenAIModel, setSelectedOpenAIModel] = useState(OPENAI_MODELS[0].id);
  const [showGeminiDropdown, setShowGeminiDropdown] = useState(false);
  const [showOpenAIDropdown, setShowOpenAIDropdown] = useState(false);

  const groupedFindings = useMemo(() => {
    return selectedFindings.reduce((acc, finding) => {
      if (!acc[finding.organId]) {
        acc[finding.organId] = [];
      }
      acc[finding.organId].push(finding);
      return acc;
    }, {} as Record<string, SelectedFinding[]>);
  }, [selectedFindings]);

  const organMap = useMemo(() => {
    return organsList.reduce<Record<string, Organ>>((acc, organ) => {
      acc[organ.id] = organ;
      return acc;
    }, {});
  }, [organsList]);

  const uniqueNormalOrgans = useMemo(() => new Set(normalOrgans), [normalOrgans]);
  const uniqueOrgansWithFindings = useMemo(
    () => new Set(Object.keys(groupedFindings)),
    [groupedFindings]
  );

  const coveragePercentage = organsList.length > 0
    ? Math.min(
      100,
      Math.round(
        ((uniqueNormalOrgans.size + uniqueOrgansWithFindings.size) / organsList.length) * 100
      )
    )
    : 0;

  const handleGenerateReport = () => {
    const reportData: ReportData = {
      selectedFindings,
      normalOrgans,
      additionalNotes: ''
    };

    // Determinar qual modelo específico usar baseado no provider
    const specificModel = selectedModel === 'gemini' ? selectedGeminiModel : selectedOpenAIModel;

    onGenerateReport(reportData, {
      model: selectedModel,
      specificModel
    });
  };

  // Calculate dynamic height based on content
  const hasContent = selectedFindings.length > 0 || normalOrgans.length > 0;
  const itemCount = selectedFindings.length + (normalOrgans.length > 0 ? 1 : 0);
  const dynamicMaxHeight = hasContent
    ? `min(calc(100vh - 8rem), ${Math.max(400, Math.min(700, 300 + itemCount * 40))}px)`
    : '400px';

  const panelStyle = expandToContent
    ? undefined
    : {
        maxHeight: dynamicMaxHeight,
        minHeight: hasContent ? '300px' : '250px'
      };

  return (
    <section
      aria-labelledby="achados-titulo"
      className={cn(
        "w-56 md:w-64 lg:w-72 xl:w-80 bg-sidebar-background/95 backdrop-blur-sm rounded-xl shadow-xl border border-border/20 flex flex-col transition-all duration-300",
        className
      )}
      style={panelStyle}
    >
      {/* Header */}
      <div className="p-4 border-b border-border/20 bg-sidebar-background rounded-t-xl">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <FileText size={18} className="text-sidebar-foreground" />
            <h2 id="achados-titulo" className="text-sm font-semibold text-sidebar-foreground">
              Achados Selecionados
            </h2>
          </div>
          <Badge
            variant="secondary"
            className="text-[10px] px-2 py-0.5 bg-sidebar-muted text-sidebar-foreground"
          >
            {selectedFindings.length} registro{selectedFindings.length === 1 ? '' : 's'}
          </Badge>
        </div>

        <div className="mt-3 space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-sidebar-foreground opacity-70">
              Órgãos cobertos
            </span>
            <span className="text-sidebar-foreground font-medium">
              {uniqueOrgansWithFindings.size + uniqueNormalOrgans.size}/{organsList.length}
            </span>
          </div>
          <div className="h-1.5 bg-sidebar-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-accent transition-all duration-300"
              style={{ width: `${coveragePercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className={cn("flex-1 p-4", !expandToContent && "overflow-y-auto")}>
        {Object.keys(groupedFindings).length === 0 && normalOrgans.length === 0 ? (
          <p className="text-xs text-sidebar-foreground opacity-60 text-center py-8">
            Nenhum achado selecionado
          </p>
        ) : (
          <div className="space-y-3">
            {/* Pathological findings */}
            {Object.entries(groupedFindings).map(([organId, findings]) => {
              const organ = organMap[organId];
              return (
                <div key={organId} className="space-y-1.5">
                  <h4 className="font-medium text-xs text-sidebar-accent">
                    {organ?.name}
                  </h4>
                  <div className="space-y-1 pl-2">
                    {findings.map((finding) => (
                      <div key={finding.findingId} className="finding-item finding-item-new">
                        <div className="flex items-start gap-1">
                          <span className="text-xs text-sidebar-foreground opacity-90">
                            {finding.finding.name}
                          </span>
                          {finding.severity && (
                            <Badge
                              variant="secondary"
                              className="text-[10px] px-1 py-0 h-3.5 bg-sidebar-muted text-sidebar-foreground"
                            >
                              {finding.severity}
                            </Badge>
                          )}
                        </div>

                        {/* Show instances */}
                        {finding.instances && finding.instances.length > 0 && (
                          <div className="pl-3 mt-1 space-y-1">
                            {finding.instances.map((instance, idx) => (
                              <div key={instance.id} className="bg-sidebar-muted/30 rounded px-2 py-1.5 border border-sidebar-muted/50">
                                <div className="text-[11px] font-semibold text-sidebar-accent flex items-center gap-1">
                                  <span className="w-1.5 h-1.5 bg-sidebar-accent rounded-full"></span>
                                  Lesão {idx + 1}
                                </div>
                                <div className="text-[10px] text-sidebar-foreground opacity-90 space-y-0.5 mt-1 pl-2.5">
                                  {instance.measurements.size && (
                                    <div>• Tamanho: {instance.measurements.size}</div>
                                  )}
                                  {instance.measurements.location && (
                                    <div>• Localização: {instance.measurements.location}</div>
                                  )}
                                  {instance.measurements.segment && (
                                    <div>• Segmento: {instance.measurements.segment}</div>
                                  )}
                                  {instance.measurements.vps && (
                                    <div>• VPS: {instance.measurements.vps}</div>
                                  )}
                                  {instance.measurements.vdf && (
                                    <div>• VDF: {instance.measurements.vdf}</div>
                                  )}
                                  {(instance.measurements.ratioICA_CCA || instance.measurements.ratio) && (
                                    <div>• Razão ICA/CCA: {instance.measurements.ratioICA_CCA || instance.measurements.ratio}</div>
                                  )}
                                  {(instance.measurements.nascetGrade || instance.measurements.nascet) && (
                                    <div>• NASCET: {instance.measurements.nascetGrade || instance.measurements.nascet}</div>
                                  )}
                                  {(instance.measurements.emi || instance.measurements.emiValue) && (
                                    <div>• EMI: {instance.measurements.emi || instance.measurements.emiValue} mm</div>
                                  )}
                                  {(instance.measurements.plaqueEchogenicity || instance.measurements.echogenicity) && (
                                    <div>• Ecogenicidade: {instance.measurements.plaqueEchogenicity || instance.measurements.echogenicity}</div>
                                  )}
                                  {(instance.measurements.plaqueComposition || instance.measurements.composition) && (
                                    <div>• Composição: {instance.measurements.plaqueComposition || instance.measurements.composition}</div>
                                  )}
                                  {(instance.measurements.plaqueSurface || instance.measurements.surface) && (
                                    <div>• Superfície: {instance.measurements.plaqueSurface || instance.measurements.surface}</div>
                                  )}
                                  {(instance.measurements.plaqueRisk || instance.measurements.risk) && (
                                    <div>• Risco: {instance.measurements.plaqueRisk || instance.measurements.risk}</div>
                                  )}
                                  {instance.measurements.vertebralVelocity && (
                                    <div>• Velocidade vertebral: {instance.measurements.vertebralVelocity}</div>
                                  )}
                                  {instance.measurements.vertebralIR && (
                                    <div>• IR vertebral: {instance.measurements.vertebralIR}</div>
                                  )}
                                  {(instance.measurements.vertebralFlowPattern || instance.measurements.flowPattern) && (
                                    <div>• Padrão de fluxo: {instance.measurements.vertebralFlowPattern || instance.measurements.flowPattern}</div>
                                  )}
                                  {instance.measurements.subclavianSteal && (
                                    <div>• Roubo da subclávia: {instance.measurements.subclavianSteal}</div>
                                  )}
                                  {instance.measurements.description && (
                                    <div>• Obs: {instance.measurements.description}</div>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}

            {/* Normal organs */}
            {normalOrgans.length > 0 && (
              <div className="space-y-1.5">
                <h4 className="font-medium text-xs text-green-500">
                  Órgãos Normais
                </h4>
                <div className="flex flex-wrap gap-1 pl-2">
                  {normalOrgans.map((organId) => {
                    const organ = organMap[organId];
                    return (
                      <Badge
                        key={organId}
                        variant="outline"
                        className="text-[10px] px-2 py-0.5 border-green-500/30 text-sidebar-foreground"
                      >
                        {organ?.name}
                      </Badge>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer - AI Model Selection and Generate Button */}
      <div className="p-4 border-t border-border/20 bg-sidebar-background space-y-3 relative rounded-b-xl">
        {/* AI Model Selection with Dropdowns */}
        <div>
          <h3 className="text-xs font-medium mb-2 text-sidebar-foreground opacity-70">
            Modelo de IA:
          </h3>
          <div className="flex gap-2">
            {/* Gemini Button with Dropdown */}
            <div className="flex-1 relative z-[55]">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedModel('gemini');
                  setShowGeminiDropdown(!showGeminiDropdown);
                  setShowOpenAIDropdown(false);
                }}
                className={cn(
                  "w-full px-3 py-1.5 text-xs rounded-md font-medium transition-all flex items-center justify-between gap-1",
                  selectedModel === 'gemini'
                    ? "bg-accent text-accent-foreground shadow-sm"
                    : "bg-sidebar-muted text-sidebar-foreground opacity-70 border border-white/10 hover:opacity-100"
                )}
              >
                <span className="truncate">
                  {GEMINI_MODELS.find(m => m.id === selectedGeminiModel)?.name || 'Gemini'}
                </span>
                <CaretDown size={12} className={cn("transition-transform", showGeminiDropdown && "rotate-180")} />
              </button>

              {/* Gemini Dropdown */}
              {showGeminiDropdown && (
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="absolute bottom-full left-0 right-0 mb-1 bg-sidebar-background border border-border/20 rounded-md shadow-lg overflow-hidden z-[60]"
                  data-custom-dropdown="open">
                  {GEMINI_MODELS.map((model) => (
                    <button
                      key={model.id}
                      onClick={() => {
                        setSelectedGeminiModel(model.id);
                        setSelectedModel('gemini');
                        setShowGeminiDropdown(false);
                      }}
                      className={cn(
                        "w-full px-3 py-2 text-left text-xs hover:bg-sidebar-muted transition-colors",
                        selectedGeminiModel === model.id && "bg-accent/10"
                      )}
                    >
                      <div className="font-medium text-sidebar-foreground">{model.name}</div>
                      <div className="text-[10px] text-sidebar-foreground opacity-60">{model.description}</div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* OpenAI Button with Dropdown */}
            <div className="flex-1 relative z-[55]">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedModel('openai');
                  setShowOpenAIDropdown(!showOpenAIDropdown);
                  setShowGeminiDropdown(false);
                }}
                className={cn(
                  "w-full px-3 py-1.5 text-xs rounded-md font-medium transition-all flex items-center justify-between gap-1",
                  selectedModel === 'openai'
                    ? "bg-accent text-accent-foreground shadow-sm"
                    : "bg-sidebar-muted text-sidebar-foreground opacity-70 border border-white/10 hover:opacity-100"
                )}
              >
                <span className="truncate">
                  {OPENAI_MODELS.find(m => m.id === selectedOpenAIModel)?.name || 'OpenAI'}
                </span>
                <CaretDown size={12} className={cn("transition-transform", showOpenAIDropdown && "rotate-180")} />
              </button>

              {/* OpenAI Dropdown */}
              {showOpenAIDropdown && (
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="absolute bottom-full left-0 right-0 mb-1 bg-sidebar-background border border-border/20 rounded-md shadow-lg overflow-hidden z-[60]"
                  data-custom-dropdown="open">
                  {OPENAI_MODELS.map((model) => (
                    <button
                      key={model.id}
                      onClick={() => {
                        setSelectedOpenAIModel(model.id);
                        setSelectedModel('openai');
                        setShowOpenAIDropdown(false);
                      }}
                      className={cn(
                        "w-full px-3 py-2 text-left text-xs hover:bg-sidebar-muted transition-colors",
                        selectedOpenAIModel === model.id && "bg-accent/10"
                      )}
                    >
                      <div className="font-medium text-sidebar-foreground">{model.name}</div>
                      <div className="text-[10px] text-sidebar-foreground opacity-60">{model.description}</div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Generate Report Button */}
        <button
          onClick={handleGenerateReport}
          disabled={isGenerating || (selectedFindings.length === 0 && normalOrgans.length === 0)}
          className="w-full py-2.5 bg-accent text-accent-foreground text-sm font-medium rounded-md hover:bg-accent/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-md"
        >
          {isGenerating ? (
            <>
              <div className="w-4 h-4 border-2 border-accent-foreground/20 border-t-accent-foreground rounded-full animate-spin" />
              Gerando...
            </>
          ) : (
            <>
              <Lightning size={16} />
              Gerar Laudo
            </>
          )}
        </button>
      </div>
    </section>
  );
}
