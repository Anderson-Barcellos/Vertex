import React from 'react';
import { useNavigate } from 'react-router-dom';

export function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 flex items-center justify-center p-4">
      <div className="max-w-6xl w-full">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center">
              <span className="text-white font-bold text-xl">US</span>
            </div>
            <div>
              <h1 className="text-4xl md:text-6xl font-bold text-white">
                VERTEX <span className="text-blue-400">V2</span>
              </h1>
            </div>
          </div>

          <p className="text-xl md:text-2xl text-blue-100 mb-4">
            Sistema de Laudos com Layout Responsivo
          </p>

          <div className="flex flex-wrap justify-center gap-4 text-sm text-blue-200">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-400 rounded-full"></span>
              CSS Grid Moderno
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-400 rounded-full"></span>
              A4 Responsivo (210→160mm)
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-400 rounded-full"></span>
              Desktop + Tablet
            </div>
          </div>
        </div>

        {/* Cards Grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {/* Abdome Total Card */}
          <div
            onClick={() => navigate('/abdome-v2')}
            className="group relative overflow-hidden bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl p-8 cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-2xl"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-transparent to-black opacity-0 group-hover:opacity-20 transition-opacity"></div>

            <div className="relative z-10">
              <div className="text-5xl mb-4">🔍</div>
              <h2 className="text-3xl font-bold text-white mb-3">
                Abdome Total
              </h2>
              <p className="text-blue-100 mb-6">
                Ultrassonografia abdominal completa com painel flutuante de achados
              </p>

              <div className="flex items-center text-white font-medium">
                <span>Acessar módulo</span>
                <span className="ml-2 group-hover:translate-x-2 transition-transform">→</span>
              </div>
            </div>
          </div>

          {/* Carotid Card */}
          <div
            onClick={() => navigate('/carotid-v2')}
            className="group relative overflow-hidden bg-gradient-to-br from-purple-600 to-purple-800 rounded-2xl p-8 cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-2xl"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-transparent to-black opacity-0 group-hover:opacity-20 transition-opacity"></div>

            <div className="relative z-10">
              <div className="text-5xl mb-4">💓</div>
              <h2 className="text-3xl font-bold text-white mb-3">
                Ecodoppler Carótidas
              </h2>
              <p className="text-purple-100 mb-6">
                Doppler vascular com campos específicos (VPS, VDF, NASCET, EMI)
              </p>

              <div className="flex items-center text-white font-medium">
                <span>Acessar módulo</span>
                <span className="ml-2 group-hover:translate-x-2 transition-transform">→</span>
              </div>
            </div>
          </div>
        </div>

        {/* Info Box - Melhorias V2 */}
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-4">
            ✨ Melhorias do Vertex V2
          </h3>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-blue-500 flex items-center justify-center flex-shrink-0">
                <span className="text-white text-lg">🎨</span>
              </div>
              <div>
                <div className="text-white font-medium mb-1">CSS Grid Layout</div>
                <div className="text-blue-200 text-sm">
                  Substituiu flex manual por grid declarativo
                </div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-purple-500 flex items-center justify-center flex-shrink-0">
                <span className="text-white text-lg">📱</span>
              </div>
              <div>
                <div className="text-white font-medium mb-1">Responsivo Real</div>
                <div className="text-blue-200 text-sm">
                  Desktop (1280px+) e Tablet (768-1024px)
                </div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-green-500 flex items-center justify-center flex-shrink-0">
                <span className="text-white text-lg">📄</span>
              </div>
              <div>
                <div className="text-white font-medium mb-1">A4 Colapsável</div>
                <div className="text-blue-200 text-sm">
                  Adapta de 210mm para 160mm em tablet
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center">
          <p className="text-blue-300 text-sm">
            Vertex V2.0.0 • Projeto paralelo de refatoração de layout
          </p>
          <p className="text-blue-400 text-xs mt-2">
            Servidor: localhost:8200 | Original: localhost:8198
          </p>
        </div>
      </div>
    </div>
  );
}

export default LandingPage;
