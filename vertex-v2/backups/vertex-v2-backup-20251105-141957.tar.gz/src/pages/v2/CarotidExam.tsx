/**
 * Vertex V2 - Carotid Exam Page (Refactored with CSS Grid)
 *
 * Uses GridExamLayout for responsive 3-column design
 * Desktop: sidebar | main-content | panels
 * Tablet: sidebar | main-content (panels below)
 */

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPortal } from 'react-dom';
import { Toaster } from 'sonner';
import { toast } from 'sonner';
import { CaretLeft, CaretRight, House } from '@phosphor-icons/react';

// Layout
import { GridExamLayout } from '@/layouts/GridExamLayout';
import '@/styles/grid-layout.css';
import '@/styles/a4-responsive.css';

// Components - Using original versions for consistency with AbdomeTotalExam
import Sidebar from '@/components/original/Sidebar';
import OrganSection from '@/components/original/OrganSection';
import ReportCanvas from '@/components/original/ReportCanvas';
import SelectedFindingsPanel from '@/components/original/SelectedFindingsPanel';
import ExamStatisticsPanel from '@/components/original/ExamStatisticsPanel';
import CarotidFindingDetails from '@/components/original/CarotidFindingDetails';

// Data & Types - Note: These need to be copied to vertex-v2 or imported from original project
import { carotidOrgans } from '@/data/carotidOrgans';
import { SelectedFinding, ReportData, FindingInstance, type AIProvider } from '@/types/report';
import { Finding } from '@/data/organs';
import type { AIStatus } from '@/components/v2/ReportCanvas';

// Services - Note: These need to be copied to vertex-v2 or imported from original project
import { generateReport } from '@/services/reportGenerator';
import { generateGeminiClinicalImpression } from '@/services/geminiClient';
import { geminiStreamService } from '@/services/geminiStreamService';
import { openaiStreamService } from '@/services/openaiStreamService';
import { unifiedAIService } from '@/services/unifiedAIService';

function CarotidExam() {
  const navigate = useNavigate();

  // Core state
  const [selectedOrgan, setSelectedOrgan] = useState('');
  const [selectedFindings, setSelectedFindings] = useState<SelectedFinding[]>([]);
  const [normalOrgans, setNormalOrgans] = useState<string[]>([]);
  const [generatedReport, setGeneratedReport] = useState<string>('');

  // AI state
  const [isGenerating, setIsGenerating] = useState(false);
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [aiImpression, setAiImpression] = useState('');
  const [currentAiModel, setCurrentAiModel] = useState<'gemini' | 'openai'>('gemini');
  const [autoGenerateAI, setAutoGenerateAI] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiStatus, setAiStatus] = useState<AIStatus>('idle');

  // Panel state
  const [isPanelMinimized, setIsPanelMinimized] = useState(false);
  const [isAnyDropdownOpen, setIsAnyDropdownOpen] = useState(false);

  // Refs
  const organPanelRef = useRef<HTMLDivElement>(null);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const findingsPanelRef = useRef<HTMLDivElement>(null);
  const aiDebounceRef = useRef<number | null>(null);
  const aiAbortRef = useRef<AbortController | null>(null);
  const statusUnsubscribeRef = useRef<(() => void) | null>(null);

  // Monitor dropdowns state via MutationObserver (more efficient than polling)
  useEffect(() => {
    const observer = new MutationObserver(() => {
      const hasOpenDropdown =
        document.querySelector('[data-state="open"]') !== null ||
        document.querySelector('[aria-expanded="true"]') !== null ||
        document.querySelector('[data-custom-dropdown="open"]') !== null;
      setIsAnyDropdownOpen(hasOpenDropdown);
    });

    // Observe only the organ panel for dropdown changes
    if (organPanelRef.current) {
      observer.observe(organPanelRef.current, {
        attributes: true,
        attributeFilter: ['data-state', 'aria-expanded', 'data-custom-dropdown'],
        subtree: true
      });
    }

    // Also observe the document body for portals
    observer.observe(document.body, {
      attributes: true,
      attributeFilter: ['data-state', 'aria-expanded', 'data-custom-dropdown'],
      subtree: true,
      childList: true
    });

    return () => observer.disconnect();
  }, [selectedOrgan]); // Re-observe when organ changes

  // Handle pointerdown outside to minimize organ panel (prevents dropdown clicks from triggering)
  useEffect(() => {
    const handlePointerDown = (event: PointerEvent) => {
      const path = typeof (event as any).composedPath === 'function' ? (event as any).composedPath() as EventTarget[] : [];
      const target = event.target as HTMLElement | null;

      // Click started inside organ panel? Never minimize.
      if (organPanelRef.current && target && organPanelRef.current.contains(target)) {
        return;
      }

      // Identify Radix Select/Dropdown elements using path and target fallbacks
      const pathIsDropdown = path.some((el) => {
        if (el && (el as any).nodeType === 1) {
          const elem = el as Element;
          const slot = elem.getAttribute('data-slot');
          const role = elem.getAttribute('role');
          return (
            elem.hasAttribute('data-radix-portal') ||
            elem.hasAttribute('data-radix-popper-content-wrapper') ||
            elem.getAttribute('data-state') === 'open' ||
            elem.getAttribute('aria-expanded') === 'true' ||
            role === 'listbox' || role === 'option' || role === 'combobox' ||
            elem.hasAttribute('data-radix-select-content') ||
            elem.hasAttribute('data-radix-select-trigger') ||
            elem.hasAttribute('data-radix-select-viewport') ||
            elem.hasAttribute('data-radix-select-item') ||
            elem.hasAttribute('data-radix-select-portal') ||
            elem.hasAttribute('data-radix-dropdown-menu-content') ||
            elem.getAttribute('data-custom-dropdown') === 'open' ||
            slot === 'select' || slot === 'select-content' || slot === 'select-trigger' || slot === 'select-item' ||
            elem.classList?.contains('select-content') ||
            elem.classList?.contains('select-trigger')
          );
        }
        return false;
      });

      const targetIsDropdown = !!target && (
        target.closest('[data-radix-portal]') ||
        target.closest('[data-radix-popper-content-wrapper]') ||
        target.closest('[data-state="open"]') ||
        target.closest('[role="listbox"]') ||
        target.closest('[role="option"]') ||
        target.closest('[role="combobox"]') ||
        target.closest('[data-radix-select-content]') ||
        target.closest('[data-radix-select-trigger]') ||
        target.closest('[data-radix-select-viewport]') ||
        target.closest('[data-radix-select-item]') ||
        target.closest('[data-radix-select-portal]') ||
        target.closest('[data-radix-dropdown-menu-content]') ||
        target.closest('[data-custom-dropdown="open"]') ||
        target.closest('[data-slot="select-content"]') ||
        target.closest('[data-slot="select-trigger"]') ||
        target.closest('[data-slot="select-item"]')
      );

      if (pathIsDropdown || targetIsDropdown) {
        return;
      }

      // Ignore clicks on sidebar and findings panel
      const clickOnSidebar = sidebarRef.current?.contains(target as Node);
      const clickOnFindings = findingsPanelRef.current?.contains(target as Node);
      if (clickOnSidebar || clickOnFindings) {
        return;
      }

      if (selectedOrgan && !isPanelMinimized) {
        setIsPanelMinimized(true);
      }
    };

    document.addEventListener('pointerdown', handlePointerDown, { capture: true });
    return () => {
      document.removeEventListener('pointerdown', handlePointerDown, { capture: true } as any);
    };
  }, [selectedOrgan, isPanelMinimized]);

  const handleOrganSelect = (organId: string) => {
    if (selectedOrgan === organId) {
      setIsPanelMinimized(!isPanelMinimized);
    } else {
      setSelectedOrgan(organId);
      setIsPanelMinimized(false);
    }
  };

  const handleFindingChange = (
    organId: string,
    categoryId: string,
    findingId: string,
    checked: boolean,
    finding: Finding,
    severity?: string,
    instances?: FindingInstance[]
  ) => {
    setSelectedFindings(currentFindings => {
      if (checked) {
        const existingIndex = currentFindings.findIndex(f => f.findingId === findingId);
        if (existingIndex >= 0) {
          const updated = [...currentFindings];
          updated[existingIndex] = {
            ...updated[existingIndex],
            severity,
            instances
          };
          return updated;
        } else {
          const newFinding: SelectedFinding = {
            organId,
            categoryId,
            findingId,
            finding,
            severity,
            instances
          };
          return [...currentFindings, newFinding];
        }
      } else {
        return currentFindings.filter(f => f.findingId !== findingId);
      }
    });

    if (checked) {
      setNormalOrgans(currentNormal =>
        currentNormal.filter(id => id !== organId)
      );
    }
  };

  const handleNormalChange = (organId: string, isNormal: boolean) => {
    if (isNormal) {
      setNormalOrgans(currentNormal => {
        if (!currentNormal.includes(organId)) {
          return [...currentNormal, organId];
        }
        return currentNormal;
      });

      setSelectedFindings(currentFindings =>
        currentFindings.filter(f => f.organId !== organId)
      );
    } else {
      setNormalOrgans(currentNormal =>
        currentNormal.filter(id => id !== organId)
      );
    }
  };

  const handleGenerateReport = async (
    data: ReportData,
    options: { model: AIProvider }
  ) => {
    setIsGenerating(true);
    try {
      const provider = options?.model ?? 'gemini';
      setCurrentAiModel(provider as 'gemini' | 'openai');
      setGeneratedReport('');

      if (provider === 'openai') {
        if (!openaiStreamService.isConfigured()) {
          toast.error('OpenAI API não está configurada. Configure VITE_OPENAI_API_KEY.');
          setIsGenerating(false);
          return;
        }

        let fullReport = '';
        await openaiStreamService.generateFullReportStream(
          {
            examType: 'Ecodoppler de Carótidas e Vertebrais',
            selectedFindings: data.selectedFindings,
            normalOrgans: data.normalOrgans,
            organsCatalog: carotidOrgans
          },
          {
            onChunk: (text) => {
              fullReport += text;
              setGeneratedReport(fullReport);
            },
            onComplete: (finalText) => {
              setGeneratedReport(finalText);
              toast.success('Relatório gerado com sucesso pelo gpt-5-nano!');
            },
            onError: (error) => {
              console.error('Erro no OpenAI:', error);
              toast.error('Erro ao gerar relatório com OpenAI.');
            }
          }
        );
      } else {
        if (!geminiStreamService.isConfigured()) {
          const report = await generateReport(data, {
            organsList: carotidOrgans,
            provider
          });
          setGeneratedReport(report);
          toast.success('Relatório gerado com sucesso!');
        } else {
          await geminiStreamService.generateFullReportStream(
            {
              examType: 'Ecodoppler de Carótidas e Vertebrais',
              selectedFindings: data.selectedFindings,
              normalOrgans: data.normalOrgans,
              organsCatalog: carotidOrgans
            },
            {
              onChunk: (accumulatedText) => {
                setGeneratedReport(accumulatedText);
              },
              onComplete: (finalText) => {
                setGeneratedReport(finalText);
                toast.success('Relatório gerado com sucesso pelo Gemini 2.5 Pro!');
              },
              onError: async (error) => {
                console.error('Erro no Gemini (streaming):', error);
                try {
                  const fallback = await generateReport(
                    {
                      selectedFindings: data.selectedFindings,
                      normalOrgans: data.normalOrgans,
                      additionalNotes: ''
                    },
                    { organsList: carotidOrgans, provider }
                  );
                  setGeneratedReport(fallback);
                  toast.error('Falha no endpoint de IA. Exibindo laudo básico.');
                } catch (fallbackErr) {
                  console.error('Falha no fallback local:', fallbackErr);
                  toast.error('Erro ao gerar relatório com Gemini.');
                }
              }
            }
          );
        }
      }
    } catch (error) {
      console.error('Error generating report:', error);
      toast.error('Erro ao gerar relatório. Tente novamente.');
    } finally {
      setIsGenerating(false);
    }
  };

  const generateAIImpression = useCallback(() => {
    if (statusUnsubscribeRef.current) {
      statusUnsubscribeRef.current();
      statusUnsubscribeRef.current = null;
    }

    if (!isAiProcessing) {
      unifiedAIService.cancelAllOperations();
    }

    if (selectedFindings.length === 0 && normalOrgans.length === 0) {
      setAiImpression('');
      setAiError('Adicione achados ou marque órgãos como normais antes de gerar a impressão');
      setIsAiProcessing(false);
      setAiStatus('idle');
      return;
    }

    unifiedAIService.setProvider(currentAiModel);

    statusUnsubscribeRef.current = unifiedAIService.onStatusChange((status) => {
      setAiStatus(status);
      setIsAiProcessing(status === 'loading' || status === 'streaming');
      if (status === 'error') {
        setAiError('Erro ao consultar a IA');
      } else {
        setAiError(null);
      }
    });

    let accumulatedText = '';
    unifiedAIService.generateClinicalImpression(
      {
        examType: 'Ecodoppler de Carótidas e Vertebrais',
        selectedFindings,
        normalOrgans,
        organsCatalog: carotidOrgans
      },
      {
        onChunk: (text) => {
          accumulatedText += text;
          setAiImpression(accumulatedText);
        },
        onComplete: (finalText) => {
          setAiImpression(finalText);
          setAiError(null);
        },
        onError: (error) => {
          setAiImpression('');
          setAiError(error.message || 'Erro desconhecido');
        }
      }
    ).catch((error) => {
      console.error('AI impression generation failed:', error);
      setAiError('Falha na geração da impressão diagnóstica');
    });
  }, [selectedFindings, normalOrgans, currentAiModel]);

  useEffect(() => {
    if (!autoGenerateAI) return;

    const timer = setTimeout(() => {
      if (selectedFindings.length > 0 || normalOrgans.length > 0) {
        generateAIImpression();
      }
    }, 2000);

    return () => {
      clearTimeout(timer);
      if (statusUnsubscribeRef.current && autoGenerateAI) {
        statusUnsubscribeRef.current();
        statusUnsubscribeRef.current = null;
      }
      if (autoGenerateAI) {
        unifiedAIService.cancelClinicalImpression();
      }
    };
  }, [selectedFindings, normalOrgans, currentAiModel, autoGenerateAI, generateAIImpression]);

  useEffect(() => {
    return () => {
      if (statusUnsubscribeRef.current) {
        statusUnsubscribeRef.current();
        statusUnsubscribeRef.current = null;
      }
      unifiedAIService.cleanup();
    };
  }, []);

  const currentOrgan = useMemo(
    () => carotidOrgans.find(organ => organ.id === selectedOrgan),
    [selectedOrgan]
  );

  const currentOrganFindings = useMemo(
    () => selectedFindings.filter(f => f.organId === selectedOrgan),
    [selectedFindings, selectedOrgan]
  );

  const isCurrentOrganNormal = useMemo(
    () => normalOrgans.includes(selectedOrgan),
    [normalOrgans, selectedOrgan]
  );

  return (
    <>
      <GridExamLayout
        sidebar={
          <div ref={sidebarRef}>
            <header className="p-4 border-b border-border/20 bg-sidebar-background">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center">
                  <span className="text-accent-foreground font-semibold text-sm">US</span>
                </div>
                <div>
                  <h1 style={{ color: 'var(--sidebar-foreground)' }} className="text-lg font-semibold">
                    VERTEX
                  </h1>
                  <p style={{ color: 'var(--sidebar-foreground)' }} className="text-sm opacity-70">
                    Ecodoppler Vascular
                  </p>
                </div>
              </div>

              <button
                onClick={() => navigate('/')}
                className="w-full mb-2 px-3 py-2 flex items-center gap-2 text-sm rounded-md hover:bg-accent/10 transition-colors"
                style={{ color: 'var(--sidebar-foreground)' }}
              >
                <House size={16} />
                <span>Voltar ao Início</span>
              </button>
            </header>

            <Sidebar
              selectedOrgan={selectedOrgan}
              onOrganSelect={handleOrganSelect}
              onNormalChange={handleNormalChange}
              selectedFindings={selectedFindings}
              normalOrgans={normalOrgans}
              organsList={carotidOrgans}
              showSummary={false}
            />
          </div>
        }
        mainContent={
          <div className="a4-container-v2">
            <ReportCanvas
              selectedFindings={selectedFindings}
              normalOrgans={normalOrgans}
              generatedReport={generatedReport}
              isGenerating={isGenerating}
              aiImpression={aiImpression}
              aiError={aiError}
              isAiLoading={isAiProcessing}
              aiStatus={aiStatus}
              organsList={carotidOrgans}
              currentAiModel={currentAiModel}
              onGenerateAI={generateAIImpression}
              autoGenerateAI={autoGenerateAI}
              onToggleAutoGenerate={setAutoGenerateAI}
            />
          </div>
        }
        panels={
          <div ref={findingsPanelRef} data-findings-panel>
            <SelectedFindingsPanel
              selectedFindings={selectedFindings}
              normalOrgans={normalOrgans}
              organsList={carotidOrgans}
              onGenerateReport={handleGenerateReport}
              isGenerating={isGenerating}
              expandToContent
            />

            <ExamStatisticsPanel
              selectedFindings={selectedFindings}
              normalOrgans={normalOrgans}
              organsList={carotidOrgans}
            />
          </div>
        }
        floatingPanel={
          currentOrgan && createPortal(
            <div
              ref={organPanelRef}
              className="fixed top-20 left-[272px] lg:left-[256px] md:left-[240px] z-50 bg-card border border-border rounded-lg shadow-2xl organ-section-panel backdrop-blur-sm transition-all duration-300"
              style={{
                width: isPanelMinimized ? '48px' : '320px',
                maxHeight: 'calc(100vh - 120px)'
              }}
            >
              {isPanelMinimized ? (
                <div
                  onClick={() => setIsPanelMinimized(false)}
                  className="p-3 flex flex-col items-center cursor-pointer hover:bg-muted/50 transition-colors h-full rounded-lg"
                  title="Expandir painel"
                >
                  <div className="mb-2 p-2">
                    <CaretRight size={16} />
                  </div>
                  <div className="writing-mode-vertical text-xs font-medium text-muted-foreground">
                    {currentOrgan.name}
                  </div>
                </div>
              ) : (
                <div className="h-full">
                  <div className="absolute top-2 right-2 z-20">
                    <button
                      onClick={() => setIsPanelMinimized(true)}
                      className="p-1 hover:bg-muted rounded-md transition-colors"
                      title="Minimizar painel"
                    >
                      <CaretLeft size={16} />
                    </button>
                  </div>
                  <OrganSection
                    organ={currentOrgan}
                    selectedFindings={currentOrganFindings}
                    onFindingChange={handleFindingChange}
                    onNormalChange={handleNormalChange}
                    isNormal={isCurrentOrganNormal}
                    FindingDetailsComponent={CarotidFindingDetails}
                  />
                </div>
              )}
            </div>,
            document.body
          )
        }
      />

      <Toaster
        position="top-right"
        richColors
        closeButton
        toastOptions={{
          style: {
            background: 'var(--background)',
            color: 'var(--foreground)',
            border: '1px solid var(--border)',
          }
        }}
      />
    </>
  );
}

export default CarotidExam;
