/**
 * Vertex V2 - useBreakpoint Hook
 *
 * Hook para detectar breakpoint atual do sistema:
 * - 'desktop': >= 1280px
 * - 'tablet': 768px - 1279px
 *
 * Usa matchMedia para eficiência e reatividade em tempo real
 */

import { useState, useEffect } from 'react';

export type Breakpoint = 'desktop' | 'tablet';

/**
 * Hook que retorna o breakpoint atual baseado no viewport
 *
 * @returns {Breakpoint} 'desktop' ou 'tablet'
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const breakpoint = useBreakpoint();
 *
 *   return (
 *     <div>
 *       {breakpoint === 'desktop' && <DesktopLayout />}
 *       {breakpoint === 'tablet' && <TabletLayout />}
 *     </div>
 *   );
 * }
 * ```
 */
export function useBreakpoint(): Breakpoint {
  // Detecta breakpoint inicial
  const getBreakpoint = (): Breakpoint => {
    if (typeof window === 'undefined') return 'desktop';

    // Tablet: 768px até 1279px
    const isTablet = window.matchMedia('(min-width: 768px) and (max-width: 1279px)').matches;

    return isTablet ? 'tablet' : 'desktop';
  };

  const [breakpoint, setBreakpoint] = useState<Breakpoint>(getBreakpoint);

  useEffect(() => {
    // Media queries para cada breakpoint
    const tabletQuery = window.matchMedia('(min-width: 768px) and (max-width: 1279px)');
    const desktopQuery = window.matchMedia('(min-width: 1280px)');

    // Handler para mudanças de breakpoint
    const handleBreakpointChange = () => {
      setBreakpoint(getBreakpoint());
    };

    // Adiciona listeners (API moderna)
    tabletQuery.addEventListener('change', handleBreakpointChange);
    desktopQuery.addEventListener('change', handleBreakpointChange);

    // Verifica breakpoint inicial
    handleBreakpointChange();

    // Cleanup
    return () => {
      tabletQuery.removeEventListener('change', handleBreakpointChange);
      desktopQuery.removeEventListener('change', handleBreakpointChange);
    };
  }, []);

  return breakpoint;
}

/**
 * Hook auxiliar que retorna booleans para cada breakpoint
 * Útil para condicionais mais legíveis
 *
 * @returns {{ isDesktop: boolean, isTablet: boolean }}
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { isDesktop, isTablet } = useBreakpointChecks();
 *
 *   return (
 *     <div className={isDesktop ? 'grid-cols-3' : 'grid-cols-2'}>
 *       Content here
 *     </div>
 *   );
 * }
 * ```
 */
export function useBreakpointChecks() {
  const breakpoint = useBreakpoint();

  return {
    isDesktop: breakpoint === 'desktop',
    isTablet: breakpoint === 'tablet',
  };
}

/**
 * Hook que retorna o valor específico para o breakpoint atual
 * Útil para valores condicionais baseados no breakpoint
 *
 * @param values - Objeto com valores por breakpoint
 * @returns {T} - Valor correspondente ao breakpoint atual
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const columns = useBreakpointValue({
 *     desktop: 3,
 *     tablet: 2
 *   });
 *
 *   return <div className={`grid-cols-${columns}`}>...</div>;
 * }
 * ```
 */
export function useBreakpointValue<T>(values: Record<Breakpoint, T>): T {
  const breakpoint = useBreakpoint();
  return values[breakpoint];
}
