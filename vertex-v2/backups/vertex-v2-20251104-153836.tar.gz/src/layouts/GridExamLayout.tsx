/**
 * Vertex V2 - GridExamLayout
 *
 * Layout base usando CSS Grid para páginas de exame
 * Adapta entre desktop (3 colunas) e tablet (2 colunas)
 */

import React from 'react';
import { useBreakpoint } from '@/hooks/useBreakpoint';
import '@/styles/grid-layout.css';
import '@/styles/a4-responsive.css';

interface GridExamLayoutProps {
  /** Conteúdo da sidebar (navegação, resumo) */
  sidebar: React.ReactNode;

  /** Conteúdo principal (A4 canvas) */
  mainContent: React.ReactNode;

  /** Painéis laterais (findings, statistics) - apenas desktop */
  panels?: React.ReactNode;

  /** Painel flutuante (organ section) renderizado via portal */
  floatingPanel?: React.ReactNode;
}

/**
 * Layout Grid para páginas de exame
 *
 * Desktop (≥1280px):
 * ┌────────────────────────────────────────┐
 * │ sidebar │ main-content │ panels        │
 * │ (256px) │ (flex 1)     │ (320px)       │
 * └────────────────────────────────────────┘
 *
 * Tablet (768-1024px):
 * ┌─────────────────────────────┐
 * │ sidebar │ main-content      │
 * │ (240px) │ (flex 1)          │
 * │         │ [panels abaixo]   │
 * └─────────────────────────────┘
 */
export function GridExamLayout({
  sidebar,
  mainContent,
  panels,
  floatingPanel
}: GridExamLayoutProps) {
  const breakpoint = useBreakpoint();
  const isDesktop = breakpoint === 'desktop';

  return (
    <>
      <div className="exam-page-container">
        <div className="exam-grid-container">
          {/* Sidebar - sempre visível */}
          <aside className="grid-area-sidebar">
            {sidebar}
          </aside>

        {/* Main Content - canvas A4 */}
        <main className="grid-area-main">
          <div className="main-content-wrapper">
            {/* A4 Canvas */}
            <div className="flex-1 flex justify-center">
              {mainContent}
            </div>

            {/* Panels em tablet: renderizados dentro do main */}
            {!isDesktop && panels && (
              <div className="panels-container">
                {panels}
              </div>
            )}
          </div>
        </main>

        {/* Panels em desktop: grid area separada */}
        {isDesktop && panels && (
          <aside className="grid-area-panels">
            <div className="panels-container">
              {panels}
            </div>
          </aside>
        )}
        </div>
      </div>

      {/* Floating Panel - renderizado via portal (fora do grid) */}
      {floatingPanel}
    </>
  );
}

export default GridExamLayout;
