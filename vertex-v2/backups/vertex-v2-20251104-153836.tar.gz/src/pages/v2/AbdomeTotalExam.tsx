/**
 * Vertex V2 - AbdomeTotalExam (Refactored with GridExamLayout)
 *
 * Migrado para usar o novo sistema de CSS Grid layout
 * - Sem flex layout manual
 * - Sem widths fixos nos componentes
 * - Floating panel via Portal com posicionamento fixed
 * - A4 container usa classe a4-container-v2
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Toaster } from 'sonner';
import Sidebar from '@/components/original/Sidebar';
import ReportCanvas from '@/components/original/ReportCanvas';
import SelectedFindingsPanel from '@/components/original/SelectedFindingsPanel';
import ExamStatisticsPanel from '@/components/original/ExamStatisticsPanel';
import { GridExamLayout } from '@/layouts/GridExamLayout';
import { organs } from '@/data/organs';
import { SelectedFinding, ReportData, FindingInstance, type AIProvider } from '@/types/report';
import { Finding } from '@/data/organs';
import { generateReport } from '@/services/reportGenerator';
import { geminiStreamService } from '@/services/geminiStreamService';
import { openaiStreamService } from '@/services/openaiStreamService';
import { unifiedAIService } from '@/services/unifiedAIService';
import type { AIStatus } from '@/components/ReportCanvas';
import { toast } from 'sonner';
import { House } from '@phosphor-icons/react';
import { FloatingOrganPanel } from '@/components/v2/FloatingOrganPanel';
import '@/styles/grid-layout.css';
import '@/styles/a4-responsive.css';

function AbdomeTotalExam() {
  const navigate = useNavigate();
  const [selectedOrgan, setSelectedOrgan] = useState('');
  const [selectedFindings, setSelectedFindings] = useState<SelectedFinding[]>([]);
  const [normalOrgans, setNormalOrgans] = useState<string[]>([]);
  const [generatedReport, setGeneratedReport] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [aiImpression, setAiImpression] = useState('');
  const [currentAiModel, setCurrentAiModel] = useState<'gemini' | 'openai'>('gemini');
  const [autoGenerateAI, setAutoGenerateAI] = useState(false); // Controle manual por padrão
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiStatus, setAiStatus] = useState<AIStatus>('idle');
  const [isPanelMinimized, setIsPanelMinimized] = useState(false);
  const [isAnyDropdownOpen, setIsAnyDropdownOpen] = useState(false);

  // Refs
  const organPanelRef = useRef<HTMLDivElement>(null);
  const debounceRef = useRef<NodeJS.Timeout>();
  const aiDebounceRef = useRef<number | null>(null);
  const aiAbortRef = useRef<AbortController | null>(null);
  const statusUnsubscribeRef = useRef<(() => void) | null>(null);

  const handleOrganSelect = (organId: string) => {
    if (selectedOrgan === organId) {
      // Toggle minimized state if same organ is selected
      setIsPanelMinimized(!isPanelMinimized);
    } else {
      // Select new organ and ensure panel is expanded
      setSelectedOrgan(organId);
      setIsPanelMinimized(false);
    }
  };

  const handleFindingChange = (
    organId: string,
    categoryId: string,
    findingId: string,
    checked: boolean,
    finding: Finding,
    severity?: string,
    instances?: FindingInstance[]
  ) => {
    setSelectedFindings(currentFindings => {
      if (checked) {
        // Update existing finding or add new one
        const existingIndex = currentFindings.findIndex(f => f.findingId === findingId);
        if (existingIndex >= 0) {
          // Update existing
          const updated = [...currentFindings];
          updated[existingIndex] = {
            ...updated[existingIndex],
            severity,
            instances
          };
          return updated;
        } else {
          // Add new
          const newFinding: SelectedFinding = {
            organId,
            categoryId,
            findingId,
            finding,
            severity,
            instances
          };
          return [...currentFindings, newFinding];
        }
      } else {
        return currentFindings.filter(f => f.findingId !== findingId);
      }
    });

    if (checked) {
      setNormalOrgans(currentNormal =>
        currentNormal.filter(id => id !== organId)
      );
    }
  };

  const handleNormalChange = (organId: string, isNormal: boolean) => {
    if (isNormal) {
      setNormalOrgans(currentNormal => {
        if (!currentNormal.includes(organId)) {
          return [...currentNormal, organId];
        }
        return currentNormal;
      });

      setSelectedFindings(currentFindings =>
        currentFindings.filter(f => f.organId !== organId)
      );
    } else {
      setNormalOrgans(currentNormal =>
        currentNormal.filter(id => id !== organId)
      );
    }
  };

  const handleGenerateReport = async (
    data: ReportData,
    options: { model: AIProvider }
  ) => {
    setIsGenerating(true);
    try {
      const provider = options?.model ?? 'gemini';
      setCurrentAiModel(provider as 'gemini' | 'openai');
      setGeneratedReport(''); // Clear previous report

      if (provider === 'openai') {
        // Use OpenAI streaming service
        if (!openaiStreamService.isConfigured()) {
          toast.error('OpenAI API não está configurada. Configure VITE_OPENAI_API_KEY.');
          setIsGenerating(false);
          return;
        }

        let fullReport = '';
        await openaiStreamService.generateFullReportStream(
          {
            examType: 'Ultrassonografia Abdominal Total',
            selectedFindings: data.selectedFindings,
            normalOrgans: data.normalOrgans,
            organsCatalog: organs
          },
          {
            onChunk: (text) => {
              fullReport += text;
              setGeneratedReport(fullReport);
            },
            onComplete: (finalText) => {
              setGeneratedReport(finalText);
              toast.success('Relatório gerado com sucesso pelo gpt-5-nano!');
            },
            onError: (error) => {
              console.error('Erro no OpenAI:', error);
              toast.error('Erro ao gerar relatório com OpenAI.');
            }
          }
        );
      } else {
        // Use Gemini streaming service
        if (!geminiStreamService.isConfigured()) {
          // Fallback to non-streaming Gemini
          const report = await generateReport(data, {
            organsList: organs,
            provider
          });
          setGeneratedReport(report);
          toast.success('Relatório gerado com sucesso!');
        } else {
          // Streaming do Gemini com chunks em tempo real
          await geminiStreamService.generateFullReportStream(
            {
              examType: 'Ultrassonografia Abdominal Total',
              selectedFindings: data.selectedFindings,
              normalOrgans: data.normalOrgans,
              organsCatalog: organs
            },
            {
              onChunk: (accumulatedText) => {
                // O texto já vem acumulado do serviço
                setGeneratedReport(accumulatedText);
              },
              onComplete: (finalText) => {
                setGeneratedReport(finalText);
                toast.success('Relatório gerado com sucesso pelo Gemini 2.5 Pro!');
              },
              onError: async (error) => {
                console.error('Erro no Gemini (streaming):', error);
                // Fallback automático para geração local/não-streaming
                try {
                  const fallback = await generateReport(
                    {
                      selectedFindings: data.selectedFindings,
                      normalOrgans: data.normalOrgans,
                      additionalNotes: ''
                    },
                    { organsList: organs, provider }
                  );
                  setGeneratedReport(fallback);
                  toast.error('Falha no endpoint de IA. Exibindo laudo básico.');
                } catch (fallbackErr) {
                  console.error('Falha no fallback local:', fallbackErr);
                  toast.error('Erro ao gerar relatório com Gemini.');
                }
              }
            }
          );
        }
      }
    } catch (error) {
      console.error('Error generating report:', error);
      toast.error('Erro ao gerar relatório. Tente novamente.');
    } finally {
      setIsGenerating(false);
    }
  };

  // Função manual para gerar impressão diagnóstica com IA
  const generateAIImpression = useCallback(() => {
    // Cleanup previous operations
    if (statusUnsubscribeRef.current) {
      statusUnsubscribeRef.current();
      statusUnsubscribeRef.current = null;
    }

    // Cancelar operações anteriores apenas se não estiver em andamento
    if (!isAiProcessing) {
      unifiedAIService.cancelAllOperations();
    }

    // Clear state if no findings
    if (selectedFindings.length === 0 && normalOrgans.length === 0) {
      setAiImpression('');
      setAiError('Adicione achados ou marque órgãos como normais antes de gerar a impressão');
      setIsAiProcessing(false);
      setAiStatus('idle');
      return;
    }

    // Set current AI provider
    unifiedAIService.setProvider(currentAiModel);

    // Subscribe to status changes
    statusUnsubscribeRef.current = unifiedAIService.onStatusChange((status) => {
      setAiStatus(status);
      setIsAiProcessing(status === 'loading' || status === 'streaming');
      if (status === 'error') {
        setAiError('Erro ao consultar a IA');
      } else {
        setAiError(null);
      }
    });

    // Start AI impression generation
    let accumulatedText = '';
    unifiedAIService.generateClinicalImpression(
      {
        examType: 'Ultrassonografia Abdominal Total',
        selectedFindings,
        normalOrgans,
        organsCatalog: organs
      },
      {
        onChunk: (text) => {
          accumulatedText += text;
          setAiImpression(accumulatedText);
        },
        onComplete: (finalText) => {
          setAiImpression(finalText);
          setAiError(null);
        },
        onError: (error) => {
          setAiImpression('');
          setAiError(error.message || 'Erro desconhecido');
        }
      }
    ).catch((error) => {
      console.error('AI impression generation failed:', error);
      setAiError('Falha na geração da impressão diagnóstica');
    });
  }, [selectedFindings, normalOrgans, currentAiModel, isAiProcessing]);

  // Monitor dropdowns state via MutationObserver (more efficient than polling)
  useEffect(() => {
    const observer = new MutationObserver(() => {
      const hasOpenDropdown =
        document.querySelector('[data-state="open"]') !== null ||
        document.querySelector('[aria-expanded="true"]') !== null ||
        document.querySelector('[data-custom-dropdown="open"]') !== null;
      setIsAnyDropdownOpen(hasOpenDropdown);
    });

    // Observe the document body for dropdown changes
    observer.observe(document.body, {
      attributes: true,
      attributeFilter: ['data-state', 'aria-expanded', 'data-custom-dropdown'],
      subtree: true,
      childList: true
    });

    return () => observer.disconnect();
  }, []);

  // Handle click outside with debounce to prevent race conditions
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      // Don't minimize if any dropdown is open
      if (isAnyDropdownOpen) {
        return;
      }

      const target = event.target as HTMLElement;

      // Ignore clicks inside the organ panel
      if (organPanelRef.current?.contains(target)) {
        return;
      }

      // Ignore clicks on Radix UI portals and dropdowns
      const isRadixPortal =
        target.closest('[data-radix-portal]') ||
        target.closest('[data-state="open"]') ||
        target.closest('[role="listbox"]') ||
        target.closest('[data-custom-dropdown="open"]') ||
        target.closest('[role="combobox"]') ||
        target.closest('[role="menu"]') ||
        target.closest('[role="menuitem"]') ||
        target.closest('[data-radix-popper-content-wrapper]');

      if (isRadixPortal) {
        return;
      }

      // Ignore clicks on sidebar
      const isFromSidebar = target.closest('[data-sidebar]') ||
        target.closest('aside');
      if (isFromSidebar) {
        return;
      }

      // Debounce to prevent race conditions
      clearTimeout(debounceRef.current);
      debounceRef.current = setTimeout(() => {
        if (selectedOrgan && !isPanelMinimized) {
          setIsPanelMinimized(true);
        }
      }, 50); // 50ms debounce as documented in README
    };

    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
      clearTimeout(debounceRef.current);
    };
  }, [selectedOrgan, isPanelMinimized, isAnyDropdownOpen]);

  // Efeito para geração automática (apenas se ativado)
  useEffect(() => {
    if (!autoGenerateAI) return;

    // Debounce de 2 segundos para evitar múltiplas chamadas
    const timer = setTimeout(() => {
      if (selectedFindings.length > 0 || normalOrgans.length > 0) {
        generateAIImpression();
      }
    }, 2000);

    return () => {
      clearTimeout(timer);
      if (statusUnsubscribeRef.current && autoGenerateAI) {
        statusUnsubscribeRef.current();
        statusUnsubscribeRef.current = null;
      }
      if (autoGenerateAI) {
        unifiedAIService.cancelClinicalImpression();
      }
    };
  }, [selectedFindings, normalOrgans, currentAiModel, autoGenerateAI, generateAIImpression]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (statusUnsubscribeRef.current) {
        statusUnsubscribeRef.current();
        statusUnsubscribeRef.current = null;
      }
      unifiedAIService.cleanup();
    };
  }, []);

  const currentOrgan = organs.find(organ => organ.id === selectedOrgan);
  const currentOrganFindings = selectedFindings.filter(f => f.organId === selectedOrgan);
  const isCurrentOrganNormal = normalOrgans.includes(selectedOrgan);

  return (
    <>
      <GridExamLayout
        sidebar={
        <div>
          <header className="p-4 border-b border-border/20 bg-sidebar-background">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center">
                <span className="text-accent-foreground font-semibold text-sm">US</span>
              </div>
              <div>
                <h1 style={{ color: 'var(--sidebar-foreground)' }} className="text-lg font-semibold">
                  VERTEX
                </h1>
                <p style={{ color: 'var(--sidebar-foreground)' }} className="text-sm opacity-70">
                  Ultrassonografia abdominal
                </p>
              </div>
            </div>

            {/* Home button */}
            <button
              onClick={() => navigate('/')}
              className="w-full mb-2 px-3 py-2 flex items-center gap-2 text-sm rounded-md hover:bg-accent/10 transition-colors"
              style={{ color: 'var(--sidebar-foreground)' }}
            >
              <House size={16} />
              <span>Voltar ao Início</span>
            </button>
          </header>

          <Sidebar
            selectedOrgan={selectedOrgan}
            onOrganSelect={handleOrganSelect}
            onNormalChange={handleNormalChange}
            selectedFindings={selectedFindings}
            normalOrgans={normalOrgans}
            organsList={organs}
            showSummary={false}
            showFindings={false}
          />
        </div>
      }
      mainContent={
        <div className="a4-container-v2">
          <ReportCanvas
            selectedFindings={selectedFindings}
            normalOrgans={normalOrgans}
            generatedReport={generatedReport}
            isGenerating={isGenerating}
            aiImpression={aiImpression}
            aiError={aiError}
            isAiLoading={isAiProcessing}
            aiStatus={aiStatus}
            organsList={organs}
            currentAiModel={currentAiModel}
            onGenerateAI={generateAIImpression}
            autoGenerateAI={autoGenerateAI}
            onToggleAutoGenerate={setAutoGenerateAI}
          />
        </div>
      }
      panels={
        <div data-findings-panel>
          <SelectedFindingsPanel
            selectedFindings={selectedFindings}
            normalOrgans={normalOrgans}
            organsList={organs}
            onGenerateReport={handleGenerateReport}
            isGenerating={isGenerating}
            expandToContent
          />

          <ExamStatisticsPanel
            selectedFindings={selectedFindings}
            normalOrgans={normalOrgans}
            organsList={organs}
          />
        </div>
      }
      floatingPanel={
        selectedOrgan ? (
          <div ref={organPanelRef}>
            <FloatingOrganPanel
              organ={currentOrgan ?? null}
              selectedFindings={currentOrganFindings}
              isNormal={isCurrentOrganNormal}
              isMinimized={isPanelMinimized}
              onToggleMinimized={setIsPanelMinimized}
              onFindingChange={handleFindingChange}
              onNormalChange={handleNormalChange}
            />
          </div>
        ) : null
      }
    />
      <Toaster />
    </>
  );
}

export default AbdomeTotalExam;
