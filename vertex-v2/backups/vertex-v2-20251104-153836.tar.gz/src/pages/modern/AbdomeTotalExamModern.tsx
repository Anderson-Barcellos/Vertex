/**
 * Vertex V2 - Abdome Total Exam (MODERN DESIGN)
 * Layout moderno com glassmorphism e responsividade completa
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPortal } from 'react-dom';
import { Toaster } from 'sonner';
import { CaretLeft, CaretRight, House, ArrowLeft } from '@phosphor-icons/react';

// Imports originais
import Sidebar from '@/components/original/Sidebar';
import OrganSection from '@/components/original/OrganSection';
import ReportCanvas from '@/components/original/ReportCanvas';
import SelectedFindingsPanel from '@/components/original/SelectedFindingsPanel';
import ExamStatisticsPanel from '@/components/original/ExamStatisticsPanel';
import { organs } from '@/data/organs';
import { SelectedFinding, ReportData, FindingInstance, type AIProvider } from '@/types/report';
import { Finding } from '@/data/organs';
import { generateReport } from '@/services/reportGenerator';
import { generateGeminiClinicalImpression } from '@/services/geminiClient';
import { geminiStreamService } from '@/services/geminiStreamService';
import { openaiStreamService } from '@/services/openaiStreamService';
import { unifiedAIService } from '@/services/unifiedAIService';
import type { AIStatus } from '@/components/ReportCanvas';
import { toast } from 'sonner';

// Styles
import '@/styles/modern-design.css';

function AbdomeTotalExamModern() {
  const navigate = useNavigate();
  const [selectedOrgan, setSelectedOrgan] = useState('');
  const [selectedFindings, setSelectedFindings] = useState<SelectedFinding[]>([]);
  const [normalOrgans, setNormalOrgans] = useState<string[]>([]);
  const [generatedReport, setGeneratedReport] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [aiImpression, setAiImpression] = useState('');
  const [currentAiModel, setCurrentAiModel] = useState<'gemini' | 'openai'>('gemini');
  const [autoGenerateAI, setAutoGenerateAI] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiStatus, setAiStatus] = useState<AIStatus>('idle');
  const [isPanelMinimized, setIsPanelMinimized] = useState(false);
  const [isAnyDropdownOpen, setIsAnyDropdownOpen] = useState(false);
  const organPanelRef = useRef<HTMLDivElement>(null);
  const debounceRef = useRef<NodeJS.Timeout>();
  const aiDebounceRef = useRef<number | null>(null);
  const aiAbortRef = useRef<AbortController | null>(null);
  const statusUnsubscribeRef = useRef<(() => void) | null>(null);

  // Monitor dropdowns
  useEffect(() => {
    const checkDropdowns = () => {
      const hasOpenDropdown = document.querySelector('[data-state="open"]') !== null ||
        document.querySelector('[aria-expanded="true"]') !== null;
      setIsAnyDropdownOpen(hasOpenDropdown);
    };

    const interval = setInterval(checkDropdowns, 100);
    return () => clearInterval(interval);
  }, []);

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (isAnyDropdownOpen) return;

      if (
        organPanelRef.current &&
        !organPanelRef.current.contains(event.target as Node) &&
        selectedOrgan &&
        !isPanelMinimized
      ) {
        const target = event.target as HTMLElement;

        // Ignore clicks from sidebar (organ selection buttons)
        const isFromSidebar = target.closest('[data-sidebar]') ||
          target.closest('aside.col-span-12.lg\\:col-span-3');

        const isRadixPortal = target.closest('[data-radix-portal]') ||
          target.closest('[data-state="open"]') ||
          target.closest('[role="listbox"]') ||
          target.closest('[data-custom-dropdown="open"]') ||
          target.closest('[role="combobox"]') ||
          target.closest('[role="menu"]') ||
          target.closest('[role="menuitem"]') ||
          target.closest('[data-radix-popper-content-wrapper]');

        if (!isRadixPortal && !isFromSidebar) {
          // Debounce de 50ms para evitar race conditions
          clearTimeout(debounceRef.current);
          debounceRef.current = setTimeout(() => {
            setIsPanelMinimized(true);
          }, 50);
        }
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
      clearTimeout(debounceRef.current);
    };
  }, [selectedOrgan, isPanelMinimized, isAnyDropdownOpen]);

  // Monitor dropdowns state via MutationObserver (mais eficiente que polling)
  useEffect(() => {
    const observer = new MutationObserver(() => {
      const hasOpenDropdown =
        document.querySelector('[data-state="open"]') !== null ||
        document.querySelector('[aria-expanded="true"]') !== null ||
        document.querySelector('[data-custom-dropdown="open"]') !== null;
      setIsAnyDropdownOpen(hasOpenDropdown);
    });

    // Observa mudanças no DOM para detectar dropdowns
    observer.observe(document.body, {
      attributes: true,
      attributeFilter: ['data-state', 'aria-expanded', 'data-custom-dropdown'],
      subtree: true,
      childList: true
    });

    return () => observer.disconnect();
  }, []);

  const handleOrganSelect = (organId: string) => {
    if (selectedOrgan === organId) {
      setIsPanelMinimized(!isPanelMinimized);
    } else {
      setSelectedOrgan(organId);
      setIsPanelMinimized(false);
    }
  };

  const handleFindingChange = (
    organId: string,
    categoryId: string,
    findingId: string,
    checked: boolean,
    finding: Finding,
    severity?: string,
    instances?: FindingInstance[]
  ) => {
    setSelectedFindings(currentFindings => {
      if (checked) {
        const existingIndex = currentFindings.findIndex(f => f.findingId === findingId);
        if (existingIndex >= 0) {
          const updated = [...currentFindings];
          updated[existingIndex] = {
            ...updated[existingIndex],
            severity,
            instances
          };
          return updated;
        } else {
          const newFinding: SelectedFinding = {
            organId,
            categoryId,
            findingId,
            finding,
            severity,
            instances
          };
          return [...currentFindings, newFinding];
        }
      } else {
        return currentFindings.filter(f => f.findingId !== findingId);
      }
    });

    if (checked) {
      setNormalOrgans(currentNormal =>
        currentNormal.filter(id => id !== organId)
      );
    }
  };

  const handleNormalChange = (organId: string, isNormal: boolean) => {
    if (isNormal) {
      setNormalOrgans(currentNormal => {
        if (!currentNormal.includes(organId)) {
          return [...currentNormal, organId];
        }
        return currentNormal;
      });

      setSelectedFindings(currentFindings =>
        currentFindings.filter(f => f.organId !== organId)
      );
    } else {
      setNormalOrgans(currentNormal =>
        currentNormal.filter(id => id !== organId)
      );
    }
  };

  const handleGenerateReport = async (
    data: ReportData,
    options: { model: AIProvider }
  ) => {
    setIsGenerating(true);
    try {
      const provider = options?.model ?? 'gemini';
      setCurrentAiModel(provider as 'gemini' | 'openai');
      setGeneratedReport('');

      if (provider === 'openai') {
        if (!openaiStreamService.isConfigured()) {
          toast.error('OpenAI API não está configurada.');
          setIsGenerating(false);
          return;
        }

        let fullReport = '';
        await openaiStreamService.generateFullReportStream(
          {
            examType: 'Ultrassonografia Abdominal Total',
            selectedFindings: data.selectedFindings,
            normalOrgans: data.normalOrgans,
            organsCatalog: organs
          },
          {
            onChunk: (text) => {
              fullReport += text;
              setGeneratedReport(fullReport);
            },
            onComplete: (finalText) => {
              setGeneratedReport(finalText);
              toast.success('Relatório gerado com sucesso!');
            },
            onError: (error) => {
              console.error('Erro no OpenAI:', error);
              toast.error('Erro ao gerar relatório.');
            }
          }
        );
      } else {
        if (!geminiStreamService.isConfigured()) {
          const report = await generateReport(data, {
            organsList: organs,
            provider
          });
          setGeneratedReport(report);
          toast.success('Relatório gerado!');
        } else {
          await geminiStreamService.generateFullReportStream(
            {
              examType: 'Ultrassonografia Abdominal Total',
              selectedFindings: data.selectedFindings,
              normalOrgans: data.normalOrgans,
              organsCatalog: organs
            },
            {
              onChunk: (accumulatedText) => {
                setGeneratedReport(accumulatedText);
              },
              onComplete: (finalText) => {
                setGeneratedReport(finalText);
                toast.success('Relatório gerado!');
              },
              onError: async (error) => {
                console.error('Erro no Gemini:', error);
                try {
                  const fallback = await generateReport(
                    {
                      selectedFindings: data.selectedFindings,
                      normalOrgans: data.normalOrgans,
                      additionalNotes: ''
                    },
                    { organsList: organs, provider }
                  );
                  setGeneratedReport(fallback);
                  toast.error('Falha no endpoint de IA. Exibindo laudo básico.');
                } catch (fallbackErr) {
                  console.error('Falha no fallback:', fallbackErr);
                  toast.error('Erro ao gerar relatório.');
                }
              }
            }
          );
        }
      }
    } catch (error) {
      console.error('Error generating report:', error);
      toast.error('Erro ao gerar relatório.');
    } finally {
      setIsGenerating(false);
    }
  };

  const generateAIImpression = useCallback(() => {
    if (statusUnsubscribeRef.current) {
      statusUnsubscribeRef.current();
      statusUnsubscribeRef.current = null;
    }

    if (!isAiProcessing) {
      unifiedAIService.cancelAllOperations();
    }

    if (selectedFindings.length === 0 && normalOrgans.length === 0) {
      setAiImpression('');
      setAiError('Adicione achados primeiro');
      setIsAiProcessing(false);
      setAiStatus('idle');
      return;
    }

    unifiedAIService.setProvider(currentAiModel);

    statusUnsubscribeRef.current = unifiedAIService.onStatusChange((status) => {
      setAiStatus(status);
      setIsAiProcessing(status === 'loading' || status === 'streaming');
      if (status === 'error') {
        setAiError('Erro ao consultar a IA');
      } else {
        setAiError(null);
      }
    });

    let accumulatedText = '';
    unifiedAIService.generateClinicalImpression(
      {
        examType: 'Ultrassonografia Abdominal Total',
        selectedFindings,
        normalOrgans,
        organsCatalog: organs
      },
      {
        onChunk: (text) => {
          accumulatedText += text;
          setAiImpression(accumulatedText);
        },
        onComplete: (finalText) => {
          setAiImpression(finalText);
          setAiError(null);
        },
        onError: (error) => {
          setAiImpression('');
          setAiError(error.message || 'Erro desconhecido');
        }
      }
    ).catch((error) => {
      console.error('AI failed:', error);
      setAiError('Falha na geração');
    });
  }, [selectedFindings, normalOrgans, currentAiModel, isAiProcessing]);

  useEffect(() => {
    if (!autoGenerateAI) return;

    const timer = setTimeout(() => {
      if (selectedFindings.length > 0 || normalOrgans.length > 0) {
        generateAIImpression();
      }
    }, 2000);

    return () => {
      clearTimeout(timer);
      if (statusUnsubscribeRef.current && autoGenerateAI) {
        statusUnsubscribeRef.current();
        statusUnsubscribeRef.current = null;
      }
      if (autoGenerateAI) {
        unifiedAIService.cancelClinicalImpression();
      }
    };
  }, [selectedFindings, normalOrgans, currentAiModel, autoGenerateAI, generateAIImpression]);

  useEffect(() => {
    return () => {
      if (statusUnsubscribeRef.current) {
        statusUnsubscribeRef.current();
        statusUnsubscribeRef.current = null;
      }
      unifiedAIService.cleanup();
    };
  }, []);

  const currentOrgan = organs.find(organ => organ.id === selectedOrgan);
  const currentOrganFindings = selectedFindings.filter(f => f.organId === selectedOrgan);
  const isCurrentOrganNormal = normalOrgans.includes(selectedOrgan);

  return (
    <div className="modern-layout min-h-screen">
      {/* Header Bar */}
      <header className="glass-panel mb-0 rounded-none border-0 border-b border-white/10">
        <div className="max-w-[1800px] mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/')}
              className="modern-btn-glass px-4 py-2 flex items-center gap-2"
            >
              <ArrowLeft size={18} />
              <span className="hidden md:inline">Voltar</span>
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                <span className="text-white font-bold">US</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Abdome Total</h1>
                <p className="text-xs text-gray-400">Ultrassonografia Abdominal</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Grid Layout */}
      <div className="max-w-[1800px] mx-auto px-6 py-6">
        <div className="grid grid-cols-12 gap-6">
          {/* Sidebar */}
          <aside className="col-span-12 lg:col-span-3 animate-slide-left" data-sidebar>
            <div className="glass-sidebar rounded-2xl p-6 sticky top-6 max-h-[calc(100vh-120px)] overflow-y-auto modern-scrollbar">
              <Sidebar
                selectedOrgan={selectedOrgan}
                onOrganSelect={handleOrganSelect}
                onNormalChange={handleNormalChange}
                selectedFindings={selectedFindings}
                normalOrgans={normalOrgans}
                organsList={organs}
                showSummary={false}
              />
            </div>
          </aside>

          {/* Main Content - A4 Canvas */}
          <main className="col-span-12 lg:col-span-6 animate-fade-up">
            <div className="modern-a4" style={{ transform: 'scale(1)', transformOrigin: 'top center' }}>
              <ReportCanvas
                selectedFindings={selectedFindings}
                normalOrgans={normalOrgans}
                generatedReport={generatedReport}
                isGenerating={isGenerating}
                aiImpression={aiImpression}
                aiError={aiError}
                isAiLoading={isAiProcessing}
                aiStatus={aiStatus}
                organsList={organs}
                currentAiModel={currentAiModel}
                onGenerateAI={generateAIImpression}
                autoGenerateAI={autoGenerateAI}
                onToggleAutoGenerate={setAutoGenerateAI}
              />
            </div>
          </main>

          {/* Right Panels */}
          <aside className="col-span-12 lg:col-span-3 animate-slide-right">
            <div className="sticky top-6 space-y-4 min-h-[calc(100vh-8rem)]">
              <SelectedFindingsPanel
                className="glass-panel flex-1"
                selectedFindings={selectedFindings}
                normalOrgans={normalOrgans}
                organsList={organs}
                onGenerateReport={handleGenerateReport}
                isGenerating={isGenerating}
                expandToContent
              />

              <ExamStatisticsPanel
                className="glass-panel"
                selectedFindings={selectedFindings}
                normalOrgans={normalOrgans}
                organsList={organs}
              />
            </div>
          </aside>
        </div>
      </div>

      {/* Floating Organ Panel */}
      {currentOrgan && createPortal(
        <div
          ref={organPanelRef}
          className={`fixed top-24 organ-section-panel bg-white shadow-2xl border border-gray-200 rounded-2xl transition-all duration-300 ${
            isPanelMinimized ? 'w-12' : 'w-96 max-h-[80vh] overflow-y-auto modern-scrollbar'
          }`}
          style={{
            left: 'calc(25% + 1.5rem)'
          }}
        >
          {isPanelMinimized ? (
            <div
              onClick={() => setIsPanelMinimized(false)}
              className="p-3 flex flex-col items-center cursor-pointer hover:bg-gray-100 transition-colors h-full rounded-2xl"
              title="Expandir painel"
            >
              <div className="mb-2 p-2">
                <CaretRight size={16} className="text-gray-700" />
              </div>
              <div className="writing-mode-vertical text-xs font-medium text-gray-900">
                {currentOrgan.name}
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col text-gray-900">
              <div className="absolute top-3 right-3 z-20">
                <button
                  onClick={() => setIsPanelMinimized(true)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-700"
                  title="Minimizar painel"
                >
                  <CaretLeft size={16} className="text-gray-700" />
                </button>
              </div>
              <div className="flex-1 overflow-auto modern-scrollbar">
                <OrganSection
                  organ={currentOrgan}
                  selectedFindings={currentOrganFindings}
                  onFindingChange={handleFindingChange}
                  onNormalChange={handleNormalChange}
                  isNormal={isCurrentOrganNormal}
                />
              </div>
            </div>
          )}
        </div>,
        document.body
      )}

      <Toaster position="top-right" richColors />
    </div>
  );
}

export default AbdomeTotalExamModern;
