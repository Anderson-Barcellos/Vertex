/**
 * V2 Components - Adapted for CSS Grid Layout System
 *
 * All components in this directory are adapted to work with GridExamLayout:
 * - Removed fixed width classes (w-56, w-64, xl:w-80, etc.)
 * - Use w-full to fill grid areas
 * - Removed sticky positioning (handled by GridExamLayout)
 * - ReportCanvas uses a4-container-v2 class
 */

export { default as ReportCanvas } from './ReportCanvas';
export { default as SelectedFindingsPanel } from './SelectedFindingsPanel';
export { default as ExamStatisticsPanel } from './ExamStatisticsPanel';
export { default as Sidebar } from './Sidebar';
export { default as FloatingOrganPanel } from './FloatingOrganPanel';
